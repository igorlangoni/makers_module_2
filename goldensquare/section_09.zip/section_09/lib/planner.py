class Planner():
        #PUBLIC PROPERTIES
            #contact-list
            #todo-list
            #entry-list

    def __init__(self):
        pass

    def add_diary(self, diary):
        pass

    def add_todo(self, todo_list):
        pass

    def list_of_contacts(self, diary):
        #PARAMETERS
            # diary - an instance of Diary
        #RETURN 
            # contact-list - a list w/ all phone numbers of a given Diary
        #SIDE EFFECTS
            # nothing
        pass

    # def list_of_task(self, todo_list):
    #     #PARAMETERS
    #         # diary - an instance of TodoList
    #     #RETURN 
    #         # task-list
    #     #SIDE EFFECTS
    #         # nothing
    
    # def list_of_entries(self, Diary):
    #     #PARAMETERS
    #         # diary - an instance of Diary
    #     #RETURN 
    #         # entry-list
    #     #SIDE EFFECTS
    #         # nothing